#ifndef crypto_int8_h
#define crypto_int8_h

typedef signed char crypto_int8;

#endif
