/** Automatically generated file. DO NOT MODIFY */
package org.servalproject.sam;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}