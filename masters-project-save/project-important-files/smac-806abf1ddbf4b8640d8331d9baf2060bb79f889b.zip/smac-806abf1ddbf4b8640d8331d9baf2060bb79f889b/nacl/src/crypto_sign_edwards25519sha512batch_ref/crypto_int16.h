#ifndef crypto_int16_h
#define crypto_int16_h

typedef short crypto_int16;

#endif
